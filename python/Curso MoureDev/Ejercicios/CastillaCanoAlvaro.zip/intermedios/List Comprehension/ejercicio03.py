#Contar el número de espacios en una cadena

cadena = input("Introduzca una cadena de texto: ")

num_espacios = cadena.count(' ')

print(num_espacios)