# Encuentra todos los números del 1 al 1000 que sean divisibles por 7


my_list = [ i for i in range(1, 1001) if i % 7 == 0]
print(my_list)